#!/usr/bin/env bash
# 교안 체계의 버전별 폴더 사본을 만든다. git 태그(skills-vX.Y.Z)에서 그대로 뽑으므로 태그와 글자 하나까지 같다.
# 사용: bash skills/backup_version.sh            # skills/VERSION의 버전
#       bash skills/backup_version.sh 2.4.0      # 지정한 버전
#       bash skills/backup_version.sh --all      # 태그가 있는 모든 버전(이미 있는 폴더는 건너뜀)
# 사본 자리: $LECTURE_BACKUP_DIR/vX.Y.Z/, 정하지 않으면 ~/lecture-skills-backups/vX.Y.Z/ (2026-11-18 성일 결정 "가로 진행하되 git 버전 관리도 함께(github는 노노)")
set -euo pipefail
REPO="$(cd "$(dirname "$0")/.." && pwd)"
DEST_ROOT="${LECTURE_BACKUP_DIR:-$HOME/lecture-skills-backups}"
cd "$REPO"

backup_one() {
  local ver="$1" tag="skills-v$1" dest="$DEST_ROOT/v$1"
  git rev-parse -q --verify "refs/tags/$tag" >/dev/null || { echo "태그 없음: $tag (먼저 커밋하고 태그를 다세요)"; return 1; }
  if [ -e "$dest" ]; then echo "이미 있음, 건너뜀: $dest"; return 0; fi
  mkdir -p "$dest"
  local paths=(skills)
  git cat-file -e "$tag:assets/교안설계원칙.md" 2>/dev/null && paths+=("assets/교안설계원칙.md")
  git archive "$tag" "${paths[@]}" | tar -x -C "$dest"
  local commit date
  commit="$(git rev-list -n 1 "$tag")"
  date="$(git log -1 --format=%ci "$tag")"
  {
    echo "# 교안 체계 v$ver 백업"
    echo
    echo "- 태그: $tag"
    echo "- 커밋: $commit"
    echo "- 커밋 시각: $date"
    echo "- 뽑은 시각: $(date '+%F %T')"
    echo "- 원본: kyoans 저장소의 이 태그. 이 폴더는 따르지 않는 보관본이다. 지금 판은 저장소의 skills/."
  } > "$dest/BACKUP.md"
  echo "만듦: $dest ($(find "$dest" -type f | wc -l | tr -d ' ')개 파일)"
}

if [ "${1:-}" = "--all" ]; then
  for t in $(git tag -l 'skills-v*' | sort -V); do backup_one "${t#skills-v}"; done
else
  backup_one "${1:-$(tr -d '[:space:]' < skills/VERSION)}"
fi

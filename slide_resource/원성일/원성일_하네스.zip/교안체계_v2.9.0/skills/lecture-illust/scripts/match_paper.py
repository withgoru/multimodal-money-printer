#!/usr/bin/env python3
"""생성 그림의 바탕을 슬라이드 바탕에 맞추고, 바탕을 투명하게 만들어 표시 크기로 저장한다.

사용: python3 match_paper.py <입력.png> <출력.png> [--paper F7F5F0] [--size 600x600] [--tol 6] [--opaque]

1) 가장자리 띠(바깥 3%)에서 가장 흔한 밝은 색을 바탕으로 잡는다(문서의 흰색·회색 줄을 피하려고 가장자리만 본다).
2) 채널마다 (슬라이드 바탕 / 그림 바탕)을 곱해 바탕을 슬라이드 색으로 옮긴다. 흰 면은 흰색으로 남는다.
3) 크기를 줄인 뒤, 바탕에서 ±tol 안의 픽셀을 바탕으로 본다.
   - 기본: 그 픽셀을 투명(알파 0)으로 만든다. 단일 파일 빌드의 WebP 압축이 색을 미세하게 바꿔도 사각형이 생기지 않는다.
   - --opaque: 투명 대신 슬라이드 색으로 평평하게 칠한다.
글자를 합성하지 않는다(색 보정, 투명 처리, 크기 조절만). 출력은 PNG여야 한다(투명도 보존).
"""
import argparse
from collections import Counter
from PIL import Image

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src"); ap.add_argument("dst")
    ap.add_argument("--paper", default="F7F5F0")
    ap.add_argument("--size", default=None, help="WxH, 예: 600x600 (폭은 1200 이하 권장)")
    ap.add_argument("--tol", type=int, default=6)
    ap.add_argument("--opaque", action="store_true", help="바탕을 투명 대신 슬라이드 색으로 칠한다")
    a = ap.parse_args()
    P = tuple(int(a.paper[i:i+2], 16) for i in (0, 2, 4))
    im = Image.open(a.src).convert("RGB")
    W, H = im.size
    px = im.load()
    m = max(4, int(min(W, H) * 0.03))
    c = Counter()
    def take(x, y):
        r, g, b = px[x, y]
        if (r + g + b) / 3 > 215 and not (r > 250 and g > 250 and b > 250):
            c[(r // 2 * 2, g // 2 * 2, b // 2 * 2)] += 1
    for y in list(range(m)) + list(range(H - m, H)):
        for x in range(0, W, 3): take(x, y)
    for x in list(range(m)) + list(range(W - m, W)):
        for y in range(0, H, 3): take(x, y)
    bg = c.most_common(1)[0][0] if c else P
    out = Image.merge("RGB", [band.point(lambda v, f=P[i] / max(1, bg[i]): min(255, round(v * f)))
                               for i, band in enumerate(im.split())])
    if a.size:
        w, h = (int(v) for v in a.size.lower().split("x"))
        out = out.resize((w, h), Image.LANCZOS)
    out = out.convert("RGBA")
    o = out.load(); w, h = out.size; t = a.tol; n = 0
    for y in range(h):
        for x in range(w):
            r, g, b, _ = o[x, y]
            if abs(r - P[0]) <= t and abs(g - P[1]) <= t and abs(b - P[2]) <= t + 1:
                o[x, y] = (P[0], P[1], P[2], 255 if a.opaque else 0); n += 1
    if a.opaque:
        out = out.convert("RGB")
    out.save(a.dst, optimize=True)
    print(f"{a.dst}: 바탕 {bg} -> {P}, {'칠함' if a.opaque else '투명'} {n/(w*h):.0%}, 크기 {out.size}")

if __name__ == "__main__":
    main()

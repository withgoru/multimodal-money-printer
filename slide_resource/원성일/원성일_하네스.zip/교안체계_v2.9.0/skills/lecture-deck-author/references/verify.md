# 화면 검증 (ego-browser)

모든 슬라이드의 넘침, 바닥글과의 간격, 제목 위치, 깨진 그림을 숫자로 검사하고, 주요 슬라이드는 스크린샷으로 눈으로 본다. 정적 검사만으로 "됐다"고 하지 않는다.

먼저 `ego-browser skill`로 설치 버전의 사용법을 확인한다. 아래는 2026-11-16 v2.2.1에서 쓴 스크립트다. 슬라이드 수와 단계 공개 슬라이드는 덱에서 읽으므로 덱마다 고칠 곳은 경로와 `SHOT`뿐이다(16:9 고정 무대 1600×900 기준. 반화면 덱은 662×839, 720×900 등 실제 창 크기를 넣는다). 단일 파일(`_독립형.html`)도 같은 스크립트로 검사한다.

```bash
ego-browser nodejs <<'JS'
const task = await taskSpace("덱 화면 검증");
const page = task.page("p1");
const URL = "file:///<덱 파일 경로를 퍼센트 인코딩>";
const OUT = "/<스크래치 폴더>/shots";
const SHOT = [1, 4];                       // 눈으로 볼 슬라이드 번호
await (await import("node:fs/promises")).mkdir(OUT, { recursive: true });
await page.cdp("Emulation.setDeviceMetricsOverride", { width: 1600, height: 900, deviceScaleFactor: 1, mobile: false });
await page.cdp("Network.setCacheDisabled", { cacheDisabled: true });
// 슬라이드 수와 단계 공개(.step)가 있는 슬라이드를 덱에서 읽는다
await page.goto(URL + "#1"); await page.reload(); await page.waitForTimeout(500);
const meta = await page.evaluate(() => {
  const slides = [...document.querySelectorAll(".slide")];
  return { n: slides.length, reveal: slides.map((s, i) => s.querySelector(".step") ? i + 1 : 0).filter(Boolean) };
});
const out = [];
for (let n = 1; n <= meta.n; n++) {
  // 해시만 바꾸면 덱 스크립트가 다시 돌지 않아 1번 슬라이드가 계속 측정된다. goto 뒤에 반드시 reload한다.
  await page.goto(URL + "#" + n + (meta.reveal.includes(n) ? "!" : ""));   // "!" = 단계 공개 요소를 모두 연 상태
  await page.reload();
  await page.waitForTimeout(500);
  const r = await page.evaluate(() => {
    const s = document.querySelector(".slide.active");
    const foot = s.querySelector(".foot").getBoundingClientRect();
    const els = [...s.querySelectorAll("*")].filter(e => !e.closest(".foot") && !e.closest(".note") && !e.classList.contains("sample") && e.getClientRects().length);
    const bottom = Math.max(...els.map(e => e.getBoundingClientRect().bottom));
    const title = s.querySelector("h1,h2");
    return {
      over: s.scrollHeight - s.clientHeight,                               // 0이어야 한다
      gap: Math.round(foot.top - bottom),                                   // 바닥글과의 간격(음수면 겹침)
      top: title ? Math.round(title.getBoundingClientRect().top) : null,    // 모두 같아야 한다(표지는 예외일 수 있음)
      broken: [...s.querySelectorAll("img")].filter(i => !i.complete || i.naturalWidth === 0).length,
    };
  });
  if (SHOT.includes(n)) { await page.waitForTimeout(3700); await page.screenshot({ path: `${OUT}/s${n}.png` }); }  // 키 안내 토스트가 사라진 뒤
  out.push(`${n}:${r.over}/${r.gap}/t${r.top}${r.broken ? "/BROKEN" + r.broken : ""}`);
}
console.log(JSON.stringify({ taskSpaceId: task.spaceId, slides: meta.n, reveal: meta.reveal }), out.join("  "));
JS
```
- 덱은 `#번호`로 해당 슬라이드를 열고, `#번호!`면 단계 공개 요소를 모두 연 상태로 연다(뼈대의 스크립트가 지원).
- 끝나면 별도 스크립트에서 `task.finish({ keep: [] })`로 작업 공간을 닫는다.
- 검사 기준(2026-11-16 C안): 넘침 0, 바닥글 간격 30px 이상, 제목 위치 표지 제외 동일(146px), 깨진 그림 0.

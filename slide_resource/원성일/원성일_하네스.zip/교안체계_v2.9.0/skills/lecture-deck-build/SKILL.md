---
name: lecture-deck-build
version: "2.2.1"
description: 강의 배포물 빌드. 덱 HTML을 그림(WebP 압축)·글꼴·아이콘까지 base64로 담은 단일 파일로 만들고, 핸드아웃 md를 A4 인쇄 톤 PDF로 뽑는다. 단일 파일이 기본 산출물이다. 트리거: "단일 파일로", "독립형 만들어/재생성", "배포본", "핸드아웃 PDF", "오프라인에서 열리게", "파일 하나로", 덱 HTML을 고친 직후(재생성 필수), 핸드아웃 md를 고친 뒤. 빌드 스크립트는 강의 폴더의 준비물/build_standalone.py·build_handout_pdf.py이고, 없으면 이 스킬의 scripts/에서 복사한다. 단일 파일·PDF는 배포물이라 커밋, 핸드아웃 중간 .html은 부산물이라 gitignore.
---

# lecture-deck-build: 단일 파일 덱 + 핸드아웃 PDF

> **2.2.1(2026-11-18, 교안 체계 v2.5.0)**: `split_notes.py`가 실측, 설계와 다름, 설계 메모 칸도 검토 칸으로 옮긴다(RAG 입문 덱 점검에서 나온 칸 이름).
>
> **2.2.0(2026-11-18, 교안 체계 v2.4.0)**: 조립할 때 덱 폴더의 `체계버전.md`를 읽어 덱 머리에 교안 체계 버전을 적는다. 강사 노트를 수업용과 검토 칸으로 나누는 `split_notes.py`를 더했다.
>
> **의도**: 성일 원문(2026-11-16) "html은 단일 파일로 열리도록 구성해야 함". 덱은 그림과 글꼴까지 담은 파일 하나로 어디서든(오프라인, 사내망, 메일 첨부) 열려야 한다. 편집본(`images/` 참조)은 작업용이고, 배포하고 넘기는 것은 단일 파일이다.

강의 자료는 **편집본 수정 → 배포물 재생성** 두 단계로 운영한다. 편집본과 배포물이 어긋나는 순간 사고가 난다(오즈 1회차에서 세 번).

## 0) 블록 → 덱 편집본 조립 (블록을 나눠 만든 덱만)
```bash
python3 준비물/assemble_deck.py <출력 파일 이름> [덱 폴더, 기본 04_덱]   # 예: 마케팅AI_강의덱.html 04_덱/v2.4.0
```
- `blocks/_head.html`(스타일) + `NN.html`(번호순) + `_tail.html`(스크립트)을 잇고, `NN.css`는 `</style>` 앞에 넣는다.
- 블록 수를 코드에 적지 않고 두 자리 번호 파일을 모두 찾는다. 빠진 번호가 있으면 알린다. 블록 수를 `range`로 박아 두었다가 블록을 더한 뒤 마지막 블록이 빠진 일이 있었다(2026-11-17 RAG 입문).
- 블록 파일을 고쳤으면 조립 → 단일 파일 재생성 순서로 다시 돌린다. 절차는 lecture-deck-author "블록을 나눠 만들 때".
- 덱 폴더는 교안 체계 버전마다 따로 둔다(`04_덱/vX.Y.Z/`). 덱 폴더의 `체계버전.md`에서 "교안 체계: vX.Y.Z"를 읽어 덱 머리에 `<meta name="kyoans-skills">`로 넣는다. 파일이 없으면 알린다(2.2.0, 2026-11-18).
- 옛 덱의 강사 노트에서 검토용 항목(원리, 근거, 그림, 그림 후보, 포맷, 표기, 복선, 실측, 설계와 다름, 설계 메모)을 검토 칸(`<aside class="review">`)으로 옮길 때는 `scripts/split_notes.py <블록 html>…`를 쓴다. 주의·페르소나처럼 섞인 항목은 손으로 나눈다(lecture-deck-author 원칙 2).

## 1) 덱 HTML → 단일 파일
```bash
python3 준비물/build_standalone.py <덱>.html   # → <덱>_독립형.html
```
- 로컬 그림(`src="images/…"`, `data-still`)은 Pillow로 폭 1200px 이하로 줄이고 WebP(q82)로 바꿔 base64로 넣는다. PNG를 그대로 넣으면 커진다(실측 40MB → 5MB).
- 그래서 그림은 표시 크기의 2배, 폭 1200px 이하로 만들어 두면 충분하다(lecture-illust). 투명 바탕 PNG는 투명도를 그대로 담는다. 색만 맞춘 불투명 바탕은 WebP 압축으로 미세하게 어긋나 그림 뒤에 사각형이 보일 수 있다(2026-11-16 검증 덱).
- CDN 아이콘을 넣고, Pretendard Variable의 글꼴 조각(woff2)까지 받아 넣는다. 사내망에서 CDN이 막혀도 글꼴이 바뀌지 않는다.
- GIF는 애니메이션을 지키려고 원본 그대로 넣는다.
- **확인**: 빌드 뒤 밖을 부르는 주소가 남았는지 본다.
```bash
f=<덱>_독립형.html
grep -o 'src="[^"]\{0,40\}' "$f" | grep -v 'data:'          # 비어 있어야 한다
grep -o 'https\?://[^"'"'"' )]*' "$f" | sort -u                # 주석 속 주소 말고는 없어야 한다
echo "글꼴 $(grep -o 'font/woff2;base64' "$f" | wc -l), 그림 $(grep -o 'image/webp;base64' "$f" | wc -l)"
```
- 실측(2026-11-16, RAG 하루 과정 샘플 C, 20장): 4.1MB, 글꼴 조각 92개, 그림 13개(같은 그림 재사용 포함), 밖을 부르는 주소 0.
- 폰트 CDN이 실패(403 등)하면 `<link>`를 지우고 시스템 글꼴(-apple-system, Apple SD Gothic Neo, 맑은 고딕)에 맡긴다. 이때 굵기 위계가 무너질 수 있으니 화면을 다시 본다.
- **덱 편집본을 고쳤다면 단일 파일 재생성은 필수다.**

## 2) 핸드아웃 md → A4 PDF
```bash
python3 준비물/build_handout_pdf.py <핸드아웃1>.md [<핸드아웃2>.md ...]   # → 같은 자리에 .html + .pdf
```
- 자체 경량 md 파서(의존성 0) → 강의 톤 CSS → Chrome `--headless --print-to-pdf --no-pdf-header-footer --disable-features=MacAppCodeSignClone`(전역 규칙 headless-chrome). 톤 CSS(색·글꼴)는 그 강의의 덱 값에 맞춘다.
- 렌더 확인은 만들어진 PDF나 중간 .html을 ego-browser로 열어 눈으로 본다.

## 산출물 커밋 규칙
- **커밋**: `*_독립형.html`, 핸드아웃 `.pdf`(배포물).
- **gitignore**: 핸드아웃 중간 `.html`(md에서 다시 만들 수 있는 부산물), 고객사 원본을 담은 `_private/`.
- 원본 대용량·저작권 자료는 저장소 정책을 따른다(kyoans는 `external/` 미추적).

## 정합성 체크 (빌드 전 30초)
빌드는 어긋난 편집본도 그대로 굳힌다. 재생성 전에:
1. **핸드아웃**이 덱의 실행 환경, 순서, 시나리오와 맞는가(실증 사고: 폴더명, 실행 환경, 설치 순서, 롤백 논리, 태그명이 조용히 어긋났다).
2. 그 교안 전용 md(대본)를 따로 만들었다면 덱의 강사 노트와 어긋나지 않았는가.
3. 어긋나면 편집본부터 고치고 빌드한다.

### 프롬프트·코드 전수 대조 (눈으로 말고 스크립트로)
핸드아웃(복습카드)은 덱에서 수강생이 치는 프롬프트나 코드를 하나도 빠짐없이 담아야 한다. 집에서 혼자 처음부터 끝까지 하는 것이 목적이다.
```python
import re, html
deck = open('<덱>.html', encoding='utf-8').read()
card = open('<핸드아웃>.md', encoding='utf-8').read()
blocks = re.findall(r'<div class="prompt(?! annot)[^"]*">(.*?)</div>', deck, re.S) + re.findall(r'<pre[^>]*>(.*?)</pre>', deck, re.S)
for body in blocks:
    body = re.sub(r'<button.*?</button>', '', body, flags=re.S)
    txt = html.unescape(re.sub(r'<[^>]+>', '', body)).strip()
    first = txt.split('\n')[0].strip()
    if first and first not in card:
        print('누락:', first[:60])
```
- `annot` 프롬프트(해설용 사본)는 제외한다.
- 실증(오즈 4회차): 22개 중 1개 누락을 이 방법으로 찾았다. 의도적 제외인지 사고인지 판단해 넣거나 사유를 남긴다.

## 새 강의 프로젝트에서
`준비물/build_standalone.py`, `build_handout_pdf.py`, `assemble_deck.py`(블록 조립)가 없으면 이 스킬의 `scripts/`에서 복사한 뒤 톤 CSS만 그 강의에 맞춘다.

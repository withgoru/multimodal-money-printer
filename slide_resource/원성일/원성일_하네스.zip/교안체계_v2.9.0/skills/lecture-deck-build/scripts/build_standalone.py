#!/usr/bin/env python3
"""
독립형 HTML 생성기 — 원본 강의안 HTML의 모든 외부 참조(로컬 이미지·CDN 아이콘·폰트)를
base64 data-URI로 인라인해 파일 하나로 완결. 어디서든(오프라인·전송) 열림.

사용: python3 준비물/build_standalone.py 1회차_강의안.html
  → 1회차_강의안_독립형.html 생성

원본에서 편집 후 이 스크립트를 다시 돌리면 독립형이 재생성됨.
"""
import sys, os, re, base64, mimetypes, urllib.request, io

# 이미지 표시 최대 폭(슬라이드 반쪽 이미지도 ~600px, 풀블리드도 ~1120px). 여유롭게 1200.
MAX_W = 1200
WEBP_QUALITY = 82

def data_uri(content: bytes, mime: str) -> str:
    return f"data:{mime};base64,{base64.b64encode(content).decode()}"

def compress_to_webp(full: str) -> bytes | None:
    """PNG를 표시 크기로 리사이즈 + WebP 인코딩(대폭 축소, 화질 유지)."""
    try:
        from PIL import Image
    except ImportError:
        return None
    try:
        im = Image.open(full)
        if im.mode in ("P", "LA"):
            im = im.convert("RGBA")
        if im.width > MAX_W:
            h = round(im.height * MAX_W / im.width)
            im = im.resize((MAX_W, h), Image.Resampling.LANCZOS)
        buf = io.BytesIO()
        im.save(buf, format="WEBP", quality=WEBP_QUALITY, method=6)
        return buf.getvalue()
    except Exception as e:
        print(f"  ⚠ WebP 변환 실패({e}): {full}")
        return None

def _inline_one(path: str, base_dir: str, attr: str):
    """이미지 한 개를 base64 data-URI로. GIF는 애니메이션 보존 위해 원본 그대로."""
    full = os.path.join(base_dir, path)
    if not os.path.isfile(full):
        print(f"  ⚠ 로컬 이미지 없음: {path}")
        return None
    if full.lower().endswith(".gif"):
        # GIF는 WebP 변환하면 애니메이션이 죽는다 → 원본 바이트 그대로
        with open(full, "rb") as f:
            return f'{attr}="{data_uri(f.read(), "image/gif")}"'
    webp = compress_to_webp(full)
    if webp is not None:
        return f'{attr}="{data_uri(webp, "image/webp")}"'
    mime = mimetypes.guess_type(full)[0] or "image/png"
    with open(full, "rb") as f:
        return f'{attr}="{data_uri(f.read(), mime)}"'

def inline_local_images(html: str, base_dir: str) -> str:
    # src="images/..." 와 data-still="images/..." 둘 다 인라인
    def repl(m):
        attr, path = m.group(1), m.group(2)
        out = _inline_one(path, base_dir, attr)
        return out if out else m.group(0)
    return re.sub(r'(src|data-still)="((?:\.\./)?images/[^"]+)"', repl, html)

_cache = {}
def fetch(url: str) -> bytes | None:
    if url in _cache:
        return _cache[url]
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=20) as r:
            data = r.read()
        _cache[url] = data
        return data
    except Exception as e:
        print(f"  ⚠ CDN 실패({e}): {url}")
        return None

def inline_cdn_icons(html: str) -> str:
    # simpleicons·githubavatar 등 <img src="https://...">
    def repl(m):
        url = m.group(1)
        data = fetch(url)
        if data is None:
            return m.group(0)
        # simpleicons=svg, avatar=png
        mime = "image/svg+xml" if "simpleicons" in url else (mimetypes.guess_type(url)[0] or "image/png")
        return f'src="{data_uri(data, mime)}"'
    return re.sub(r'src="(https://[^"]+)"', repl, html)

# Pretendard Variable(단일 파일) — static보다 작고 경로 안정적. 이것만 인라인.
PRETENDARD_VAR_CSS = "https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css"

def inline_font(html: str) -> str:
    """Pretendard <link>를 Variable 폰트 인라인 @font-face로 치환.
    폰트 다운로드 실패 시 <link>만 제거 → 시스템 폴백(-apple-system·Apple SD Gothic Neo)에 맡김."""
    link_re = r'<link[^>]+href="https://cdn\.jsdelivr\.net/[^"]*pretendard[^"]*\.css"[^>]*>'
    if not re.search(link_re, html):
        return html
    css_bytes = fetch(PRETENDARD_VAR_CSS)
    if css_bytes is None:
        print("  ⚠ 폰트 CSS 실패 → <link> 제거, 시스템 폴백 사용")
        return re.sub(link_re, "", html)
    css = css_bytes.decode("utf-8", "ignore")
    base = PRETENDARD_VAR_CSS.rsplit("/", 1)[0] + "/"
    ok = [True]
    def font_repl(fm):
        raw = fm.group(1).strip('\'"')
        if raw.startswith("data:"):
            return fm.group(0)
        # 상대경로 정규화(../ 처리)
        furl = raw if raw.startswith("http") else base + raw
        # ../ 를 실제로 풀어 정규 URL로
        while "/../" in furl:
            furl = re.sub(r'/[^/]+/\.\./', '/', furl, count=1)
        fdata = fetch(furl)
        if fdata is None:
            ok[0] = False
            return fm.group(0)
        fmime = "font/woff2" if furl.endswith("woff2") else "font/woff" if furl.endswith("woff") else "font/ttf"
        return f'url("{data_uri(fdata, fmime)}")'
    css2 = re.sub(r'url\(([^)]+)\)', font_repl, css)
    if not ok[0]:
        print("  ⚠ 폰트 파일 일부 실패 → <link> 제거, 시스템 폴백 사용")
        return re.sub(link_re, "", html)
    return re.sub(link_re, f"<style>\n{css2}\n</style>", html)

def main():
    if len(sys.argv) < 2:
        print("사용: python3 build_standalone.py <원본.html> [--no-font]")
        sys.exit(1)
    src = sys.argv[1]
    no_font = "--no-font" in sys.argv
    base_dir = os.path.dirname(os.path.abspath(src)) or "."
    html = open(src, encoding="utf-8").read()

    print(f"[1/4] 로컬 이미지 인라인…")
    html = inline_local_images(html, base_dir)
    print(f"[2/4] CDN 아이콘 인라인…")
    html = inline_cdn_icons(html)
    if no_font:
        print(f"[3/4] 폰트: --no-font → CDN link 유지(폴백 폰트)")
    else:
        print(f"[3/4] 폰트 인라인…(용량 큼)")
        html = inline_font(html)

    out = re.sub(r"\.html$", "_독립형.html", src)
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    size_mb = os.path.getsize(out) / 1024 / 1024
    print(f"[4/4] ✅ {out} ({size_mb:.1f}MB)")

if __name__ == "__main__":
    main()

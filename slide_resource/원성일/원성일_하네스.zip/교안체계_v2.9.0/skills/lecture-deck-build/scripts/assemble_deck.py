#!/usr/bin/env python3
"""블록 파일을 순서대로 이어 덱 편집본 하나로 만든다(lecture-deck-build).

사용: python3 준비물/assemble_deck.py <출력 파일 이름> [덱 폴더, 기본 04_덱]
  예: python3 준비물/assemble_deck.py RAG입문_강의덱.html
- <덱 폴더>/blocks/_head.html(스타일) + NN.html(슬라이드, 번호순) + _tail.html(스크립트)
- blocks/NN.css가 있으면 </style> 앞에 넣는다.
- 블록 수를 코드에 적지 않는다. blocks/ 안의 두 자리 번호 파일을 모두 찾는다.
  (블록 수를 range로 박아 두었다가 블록을 더한 뒤 마지막 블록이 빠진 일이 있었다. 2026-11-17 RAG 입문)
"""
import pathlib, re, sys
if len(sys.argv) < 2:
    sys.exit("사용: python3 준비물/assemble_deck.py <출력 파일 이름> [덱 폴더]")
base = pathlib.Path(__file__).resolve().parent.parent
root = base / (sys.argv[2] if len(sys.argv) > 2 else "04_덱")
B = root / "blocks"
head = (B / "_head.html").read_text(encoding="utf-8")
tail = (B / "_tail.html").read_text(encoding="utf-8")
extra = "".join(f"/* blocks/{p.name} */\n" + p.read_text(encoding="utf-8") + "\n" for p in sorted(B.glob("[0-9][0-9].css")))
if extra:
    head = head.replace("</style>", extra + "</style>", 1)
blocks = sorted(B.glob("[0-9][0-9].html"))
if not blocks:
    sys.exit(f"블록 파일이 없습니다: {B}")
nums = [int(p.stem) for p in blocks]
gaps = [n for n in range(nums[0], nums[-1] + 1) if n not in nums]
if gaps:
    print("빠진 번호:", ", ".join(f"{n:02d}" for n in gaps))
html = head + "\n\n".join(p.read_text(encoding="utf-8").strip() for p in blocks) + tail
# 교안 체계 버전: 덱 폴더의 체계버전.md에서 읽어 HTML 머리에 적는다(독립형만 따로 돌아다녀도 버전을 알 수 있게).
ver_file = root / "체계버전.md"
m = re.search(r"교안 체계:\s*(v[0-9.]+)", ver_file.read_text(encoding="utf-8")) if ver_file.exists() else None
if m:
    html = re.sub(r'<meta name="kyoans-skills"[^>]*>\n?', "", html)
    html = html.replace("<head>", f'<head>\n<meta name="kyoans-skills" content="{m.group(1)}">', 1)
else:
    print("체계버전.md가 없거나 '교안 체계: vX.Y.Z' 줄이 없습니다:", ver_file)
out = root / sys.argv[1]
out.write_text(html, encoding="utf-8")
print(out, "블록", len(blocks), "슬라이드", len(re.findall(r'<section class="slide"', html)), "체계", m.group(1) if m else "없음")

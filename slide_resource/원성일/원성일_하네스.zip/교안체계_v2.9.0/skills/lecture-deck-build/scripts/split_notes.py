"""강사 노트(.note)의 검토용 항목을 검토 칸(.review)으로 옮긴다. 사용: python3 split_notes.py <html> [<html>...]"""
import re, sys
MOVE = {"원리", "근거", "그림", "그림 후보", "포맷", "표기", "복선", "실측", "설계와 다름", "설계 메모"}
PAIR = re.compile(r'(\s*<dt>(.*?)</dt>\s*<dd[^>]*>.*?</dd>)', re.S)
def split(m):
    open_tag, body = m.group(1), m.group(2)
    keep, move = [], []
    for full, label in PAIR.findall(body):
        (move if re.sub(r'<[^>]+>', '', label).strip() in MOVE else keep).append(full)
    rest = PAIR.sub('', body)
    out = open_tag + ''.join(keep) + rest + '</aside>'
    if move:
        out += '\n  <aside class="review">' + ''.join(move) + '\n  </aside>'
    return out
for f in sys.argv[1:]:
    s = open(f, encoding='utf-8').read()
    n = len(re.findall(r'<aside class="note">', s))
    s2 = re.sub(r'(<aside class="note">)(.*?)</aside>', split, s, flags=re.S)
    open(f, 'w', encoding='utf-8').write(s2)
    print(f, '노트', n, '검토 칸', len(re.findall(r'<aside class="review">', s2)))

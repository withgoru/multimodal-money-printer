#!/usr/bin/env python3
"""
핸드아웃 마크다운 → 인쇄용 A4 HTML → (headless Chrome) PDF.
강의안 톤(주황 #EA580C, 프롬프트 다크박스, ✅확인 초록)에 맞춘 배포용 레이아웃.

사용: python3 준비물/build_handout_pdf.py 준비물/1회차_프롬프트_핸드아웃.md
  → 같은 폴더에 1회차_프롬프트_핸드아웃.html + .pdf 생성
의존성 없음(자체 경량 md 파서). PDF는 Chrome --print-to-pdf.
"""
import sys, os, re, html as ihtml, subprocess

CSS = """
@page { size: A4; margin: 14mm 14mm 16mm; }
:root{ --ink:#1c1917; --muted:#78716c; --line:#e7e5e4; --accent:#ea580c; --accent-soft:#fff1e9; --accent-ink:#9a3412;
  --ok:#15803d; --ok-soft:#f0fdf4; --code-bg:#1c1917; --code-ink:#fafaf9;
  --mono:"JetBrains Mono",ui-monospace,SFMono-Regular,Menlo,monospace;
  --sans:-apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Malgun Gothic","Pretendard",sans-serif; }
*{box-sizing:border-box}
body{font-family:var(--sans); color:var(--ink); line-height:1.62; font-size:11.5pt; margin:0; -webkit-print-color-adjust:exact; print-color-adjust:exact}
h1{font-size:19pt; font-weight:800; margin:0 0 4px; letter-spacing:-.02em}
h2{font-size:14pt; font-weight:800; margin:20px 0 8px; padding-bottom:5px; border-bottom:2px solid var(--accent); color:var(--accent-ink); letter-spacing:-.01em; break-after:avoid}
h3{font-size:12pt; font-weight:700; margin:14px 0 6px; break-after:avoid}
p{margin:6px 0}
strong{font-weight:700}
code{font-family:var(--mono); font-size:.86em; background:#f5f5f4; padding:1px 5px; border-radius:4px; color:#9a3412}
/* 프롬프트 코드블록 = 다크박스 */
pre{background:var(--code-bg); color:var(--code-ink); font-family:var(--mono); font-size:9.6pt; line-height:1.55;
  padding:11px 14px; border-radius:9px; white-space:pre-wrap; word-break:break-word; margin:6px 0; break-inside:avoid}
pre code{background:none; color:inherit; padding:0}
/* 인용: 기본 / ✅확인 / 🎯 목표 / 💬 / ⚠️ 구분 */
blockquote{margin:7px 0; padding:8px 13px; border-left:3px solid var(--line); background:#fafaf9; border-radius:0 8px 8px 0; break-inside:avoid; font-size:10.8pt; color:#44403c}
blockquote.confirm{border-left-color:var(--ok); background:var(--ok-soft); color:#14532d}
blockquote.goal{border-left-color:var(--accent); background:var(--accent-soft); color:var(--accent-ink)}
blockquote p{margin:2px 0}
ul,ol{margin:6px 0; padding-left:22px}
li{margin:3px 0}
table{width:100%; border-collapse:collapse; margin:8px 0; font-size:10.4pt; break-inside:avoid}
th{background:var(--ink); color:#fff; text-align:left; padding:7px 11px; font-weight:700; font-size:9.8pt}
td{padding:6px 11px; border-bottom:1px solid var(--line); vertical-align:top}
tr:nth-child(even) td{background:#fafaf9}
hr{border:none; border-top:1px solid var(--line); margin:16px 0}
.meta{color:var(--muted); font-size:10pt; margin-top:2px}
a{color:var(--accent-ink)}
img{max-width:100%; border-radius:8px; display:block}
/* 이미지 비교 그리드: <p>안의 연속 img를 감싸는 컨테이너 대신, 3열 표에 넣어 씀 */
.imgrow{display:grid; grid-template-columns:1fr 1fr 1fr; gap:6px; margin:8px 0; break-inside:avoid}
.imgrow img{width:100%; border:1px solid var(--line)}
.imgcap{font-size:9pt; color:var(--muted); text-align:center; margin-top:2px}
"""

import base64, mimetypes

def _img_data_uri(path: str, base_dir: str) -> str:
    """로컬 이미지를 base64 data-URI로 (PDF에 실제로 박히도록)."""
    full = path if os.path.isabs(path) else os.path.join(base_dir, path)
    if not os.path.isfile(full):
        return path  # 없으면 원경로 (깨진 이미지로 표시돼 눈에 띔)
    mime = mimetypes.guess_type(full)[0] or "image/png"
    with open(full, "rb") as f:
        return f"data:{mime};base64,{base64.b64encode(f.read()).decode()}"

def inline_md(s: str, base_dir: str = ".") -> str:
    s = ihtml.escape(s, quote=False)
    s = re.sub(r'`([^`]+)`', r'<code>\1</code>', s)
    s = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', s)
    # 이미지 ![alt](path) — 링크보다 먼저
    s = re.sub(r'!\[([^\]]*)\]\(([^)]+)\)',
               lambda m: f'<img alt="{m.group(1)}" src="{_img_data_uri(m.group(2), base_dir)}">', s)
    s = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', s)
    return s

def md_to_html(md: str, base_dir: str = ".") -> str:
    lines = md.split("\n")
    out, i, n = [], 0, len(lines)
    while i < n:
        ln = lines[i]
        # 코드펜스
        if ln.strip().startswith("```"):
            code = []
            i += 1
            while i < n and not lines[i].strip().startswith("```"):
                code.append(ihtml.escape(lines[i], quote=False)); i += 1
            i += 1
            out.append("<pre><code>" + "\n".join(code) + "</code></pre>")
            continue
        # 헤더
        m = re.match(r'^(#{1,3})\s+(.*)', ln)
        if m:
            lvl = len(m.group(1)); out.append(f"<h{lvl}>{inline_md(m.group(2), base_dir)}</h{lvl}>"); i += 1; continue
        # hr
        if re.match(r'^---+\s*$', ln):
            out.append("<hr>"); i += 1; continue
        # raw HTML 블록 (<div ...> ~ </div>) — 이미지 그리드 등, 그대로 통과 (안의 ![](path)만 인라인)
        if ln.lstrip().startswith("<div"):
            block = []
            while i < n:
                block.append(lines[i])
                if "</div>" in lines[i]: i += 1; break
                i += 1
            raw = "\n".join(block)
            raw = re.sub(r'!\[([^\]]*)\]\(([^)]+)\)',
                         lambda m: f'<img alt="{m.group(1)}" src="{_img_data_uri(m.group(2), base_dir)}">', raw)
            out.append(raw); continue
        # 인용(연속 묶기)
        if ln.startswith(">"):
            q = []
            while i < n and lines[i].startswith(">"):
                q.append(lines[i][1:].lstrip()); i += 1
            body = "<br>".join(inline_md(x, base_dir) for x in q if x != "")
            cls = ""
            joined = " ".join(q)
            if "✅" in joined: cls = ' class="confirm"'
            elif "🎯" in joined: cls = ' class="goal"'
            out.append(f"<blockquote{cls}><p>{body}</p></blockquote>")
            continue
        # 표
        if "|" in ln and i+1 < n and re.match(r'^\s*\|?[\s:|-]+\|', lines[i+1]):
            header = [c.strip() for c in ln.strip().strip("|").split("|")]
            i += 2
            rows = []
            while i < n and "|" in lines[i] and lines[i].strip():
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")]); i += 1
            th = "".join(f"<th>{inline_md(c, base_dir)}</th>" for c in header)
            trs = "".join("<tr>" + "".join(f"<td>{inline_md(c, base_dir)}</td>" for c in r) + "</tr>" for r in rows)
            out.append(f"<table><tr>{th}</tr>{trs}</table>")
            continue
        # 리스트(연속)
        if re.match(r'^\s*[-*]\s+', ln) or re.match(r'^\s*\d+\.\s+', ln):
            ordered = bool(re.match(r'^\s*\d+\.', ln))
            items = []
            while i < n and (re.match(r'^\s*[-*]\s+', lines[i]) or re.match(r'^\s*\d+\.\s+', lines[i])):
                items.append(re.sub(r'^\s*(?:[-*]|\d+\.)\s+', '', lines[i])); i += 1
            tag = "ol" if ordered else "ul"
            lis = "".join(f"<li>{inline_md(x, base_dir)}</li>" for x in items)
            out.append(f"<{tag}>{lis}</{tag}>")
            continue
        # 빈 줄
        if ln.strip() == "":
            i += 1; continue
        # 일반 문단
        out.append(f"<p>{inline_md(ln, base_dir)}</p>"); i += 1
    return "\n".join(out)

def find_chrome() -> str | None:
    for p in ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
              "/Applications/Chromium.app/Contents/MacOS/Chromium"]:
        if os.path.exists(p): return p
    return None

def main():
    if len(sys.argv) < 2:
        print("사용: python3 build_handout_pdf.py <핸드아웃.md> [...더]"); sys.exit(1)
    for src in sys.argv[1:]:
        md = open(src, encoding="utf-8").read()
        base_dir = os.path.dirname(os.path.abspath(src))
        body = md_to_html(md, base_dir)
        title = os.path.splitext(os.path.basename(src))[0]
        page = f"<!doctype html><html lang='ko'><head><meta charset='utf-8'><title>{title}</title><style>{CSS}</style></head><body>{body}</body></html>"
        html_out = re.sub(r'\.md$', '.html', src)
        open(html_out, "w", encoding="utf-8").write(page)
        pdf_out = re.sub(r'\.md$', '.pdf', src)
        chrome = find_chrome()
        if chrome:
            # MacAppCodeSignClone 끔: 헤드리스 실행이 남기는 앱 복제본이 쌓이면 맥 부팅이 멈춘다(progress-ledger check.py 참고).
            subprocess.run([chrome, "--headless", "--disable-gpu", "--no-pdf-header-footer",
                            "--disable-features=MacAppCodeSignClone",
                            f"--print-to-pdf={os.path.abspath(pdf_out)}",
                            "file://" + os.path.abspath(html_out)],
                           capture_output=True)
            sz = os.path.getsize(pdf_out)/1024 if os.path.exists(pdf_out) else 0
            print(f"✅ {pdf_out} ({sz:.0f}KB)  [+ {html_out}]")
        else:
            print(f"⚠ Chrome 없음 → {html_out}만 생성(수동 인쇄→PDF)")

if __name__ == "__main__":
    main()

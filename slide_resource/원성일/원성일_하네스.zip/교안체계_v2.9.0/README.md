# 교안 체계 v2.9.0 (공유본)

강사가 AI 에이전트(Claude Code)와 함께 강의를 설계하고, 슬라이드 덱과 핸드아웃까지 만드는 방법을 **스킬 넷과 원칙 문서 하나**로 정리한 묶음입니다. 만든 사람은 강사 성일이고, 실제 강의와 시험용 강의를 만들면서 버전을 올려 왔습니다. 이 묶음은 2026-11-19의 v2.9.0입니다.

## 이 체계가 하는 일

| 순서 | 스킬 | 하는 일 | 내놓는 것 |
|---|---|---|---|
| 1 | `lecture-curriculum` | 조사 → 페르소나 → 도착점(수업 다음 날의 첫 행동) → 선수지식 → 교수 전략(교수의 으뜸원리) → 블록 → 회차와 시간표 → 운영 | 강의 폴더의 설계 문서(`02_설계/`) |
| 2 | `lecture-deck-author` | 설계를 HTML 덱으로 만듭니다. 대본·시간은 강사 노트(N 키), 원리·근거·실측은 검토 칸(R 키)에 둡니다. 화면 검증, 읽는 사람 검토, 디자인 검토 같은 게이트를 거칩니다 | 덱 HTML |
| 3 | `lecture-illust` | 그림이 새로 알려 주는 것이 있는 장에만 그림을 만듭니다 | 덱에 넣을 그림 |
| 4 | `lecture-deck-build` | 덱을 그림·글꼴까지 담은 HTML 파일 하나로, 핸드아웃 md를 A4 PDF로 만듭니다 | 배포용 단일 파일, 핸드아웃 PDF |

네 스킬이 따르는 원칙의 정본은 `assets/교안설계원칙.md`입니다. 스킬 넷과 이 원칙을 묶어 "교안 체계"라고 부르고 버전 하나로 관리합니다.

이 체계가 고집하는 것 몇 가지:
- 수업 다음 날 수강생이 할 첫 행동(도착점)을 먼저 정하고, 거기서 거꾸로 설계합니다.
- 블록의 첫 장은 수강생이 풀 문제로 엽니다.
- 화면에 나오는 숫자는 강사가 수강생과 같은 환경에서 직접 잰 값을 씁니다("실측이 감을 이긴다").
- 대본, 시간, 근거를 덱 안에 둡니다. 덱 파일 하나만 있으면 강의를 다시 할 수 있습니다.
- 버전을 올릴 때마다 같은 요청으로 작은 강의를 다시 만들어 이전 버전과 견줍니다.

## 살펴보는 분께: 읽는 순서

1. `assets/교안설계원칙.md`: 원칙 전체와 바뀐 이력
2. `skills/lecture-curriculum/SKILL.md`: 설계 절차
3. `skills/lecture-deck-author/SKILL.md`: 덱 원칙과 게이트
4. `skills/CHANGELOG.md`: 버전마다 무엇을 왜 바꿨고(강사 원문), 어떻게 시험했는지
5. 사례: `skills/lecture-curriculum/references/cases/`, `skills/lecture-deck-author/references/cases/`

## 쓰실 분께: 설치와 첫 사용

필요한 것: Claude Code, Python 3, Google Chrome(핸드아웃 PDF를 만들 때). 훅은 bash와 python3가 있는 환경(맥, 리눅스, WSL)에서 돕니다.

```bash
# 1. 압축을 푼 폴더를 그대로 강의 작업 폴더로 씁니다
cd 교안체계_v2.9.0
mkdir -p .claude/skills .claude/hooks .claude/rules mine
cp -R skills/lecture-* .claude/skills/
cp 지침/CLAUDE.md .claude/CLAUDE.md
cp 지침/rules/*.md .claude/rules/
cp 지침/hooks/lecture-sync-reminder.sh .claude/hooks/
cp 지침/settings.json .claude/settings.json
cp 지침/gitignore_예시 .gitignore

# 2. (권장) 출력 스타일 fluent-korean 설치: 지침/출력스타일_fluent-korean.md

# 3. 이 폴더에서 Claude Code를 엽니다
claude
```

첫 요청 예: "비전공 실무자 20명에게 3시간 동안 생성형 AI로 보고서 초안 쓰는 법을 가르치려 해. 강의 설계해 줘." 공고나 주최측 자료가 있으면 `mine/<강의>/00_원자료/`에 넣고 함께 말하면 됩니다. 설계가 끝나면 "덱 만들어", 덱을 고친 뒤에는 "단일 파일로", "핸드아웃 PDF"라고 하면 됩니다.

- 스킬 원본은 `skills/`이고 `.claude/skills/`는 사본입니다. 원본을 고쳤으면 사본도 다시 복사하고 Claude Code 세션을 새로 엽니다. 맥과 리눅스에서는 복사 대신 링크(`ln -s ../../skills/lecture-curriculum .claude/skills/`)로 두면 맞출 일이 없습니다.
- 스킬이나 원칙을 고치면서 버전을 관리하려면 `skills/README.md`의 "버전 올리기"를 따릅니다. 폴더 사본은 `LECTURE_BACKUP_DIR`(정하지 않으면 `~/lecture-skills-backups`)에 쌓입니다.

### 폴더 약속

```
mine/<강의>/            강의 하나
├── README.md           요약, 문서 지도, 결정(이유·폐기 대안·고른 사람), 미결
├── 00_원자료/  01_조사/  02_설계/  03_실습자료/
├── 04_덱/vX.Y.Z/       교안 체계 버전마다 폴더 하나(덱, 단일 파일, 그림)
├── 05_강의기록/         회차마다 실제 소요와 피드백
├── 준비물/              빌드 스크립트 사본
└── _private/           고객사명이 남은 원본(git 밖)
external/               남의 강의 자료와 고객사 원자료(git 밖, 외부로 보내지 않음)
assets/트렌드/           강의를 넘어 쌓는 트렌드 조사
버전시험/<주제>/vX.Y.Z/   교안 체계 버전 시험(실제 강의 아님)
```

### 이 묶음에 없는 것

스킬이 불러 쓰지만 이 묶음에 넣지 않은 도구입니다. 없어도 체계는 돌아가고, 해당 단계만 다른 방법으로 하거나 건너뜁니다.

| 도구 | 쓰는 곳 | 없을 때 |
|---|---|---|
| 디자인 검토 에이전트 "마디아" | 덱 게이트 7(디자인 검토), 덱 규칙을 바꿀 때 확인 | 작성자의 개인 도구입니다. 덱을 만들지 않은 다른 검토자(새 세션의 Claude, 동료)에게 같은 질문(그림이 일을 할 곳과 방해될 곳, 화면의 문제)으로 맡깁니다 |
| codex-imagegen | `lecture-illust`의 그림 생성 | OpenAI Codex CLI의 이미지 생성을 쓰는 작성자의 스킬입니다. 다른 이미지 생성 도구로 대신합니다 |
| image-prompt | `lecture-illust`의 프롬프트 검증기 | 다른 사람이 만든 스킬입니다(MIT, kimsh-1). 없으면 검증 단계를 건너뛰고 눈으로 확인합니다 |
| kill-ai-slop | 덱 게이트의 시각 점검 | https://github.com/yetone/kill-ai-slop |
| humanize-korean | 덱 게이트의 한국어 점검 | 다른 사람이 만든 스킬입니다(MIT, epoko77-ai). 전용 에이전트가 있어야 돕니다 |
| ego-browser | 렌더 확인 | 작성자가 쓰는 브라우저입니다. 아무 브라우저로 열어 봐도 됩니다 |
| fluent-korean | 출력 스타일 | `지침/출력스타일_fluent-korean.md` |

## 읽기 전에 알아 둘 것

- 문서 곳곳의 "성일"은 이 체계를 만든 강사입니다. "성일 원문"은 그 규칙이 생긴 이유라서 그대로 두었습니다.
- 본문에 나오는 `~/dev/...` 경로, `kyoans` 저장소, 위키, 다른 하네스(hermes, codex 등)는 작성자 환경의 것입니다. 실행에 쓰는 경로(스크립트, 백업, 훅)는 받는 분 환경에 맞게 바꿔 두었고, 바뀐 이력 속의 경로는 기록이라 그대로 두었습니다.
- 고객사 자료, 작업 기록, API 키는 넣지 않았습니다. 사례에 나오는 숫자는 작성자가 그때 잰 값입니다.

## 구성과 버전

```
README.md                 이 문서
assets/교안설계원칙.md       원칙의 정본
skills/                   스킬 넷의 원본, VERSION, CHANGELOG.md, README.md(버전 관리), backup_version.sh
지침/CLAUDE.md             작업 폴더의 지침(작업 방식, 한국어 출력, 쓰기 규칙 불러오기)
지침/rules/                쓰기 규칙 둘: 일반 낱말로 쓰기(plain-words), 독자 입장(user-perspective)
지침/hooks/, settings.json 덱·핸드아웃·실습 자료를 고칠 때 할 일을 알려 주는 훅과 그 등록
지침/gitignore_예시        작업 폴더의 .gitignore
지침/출력스타일_fluent-korean.md
```

교안 체계 v2.9.0(2026-11-19): lecture-curriculum 2.8.0 · lecture-deck-author 2.8.0 · lecture-deck-build 2.2.1 · lecture-illust 2.2.0 · 교안설계원칙 v2.9

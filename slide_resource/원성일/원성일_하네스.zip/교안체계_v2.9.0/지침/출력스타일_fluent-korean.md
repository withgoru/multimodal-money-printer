# 출력 스타일: fluent-korean

교안 체계는 한국어 결과물(강의안, 슬라이드 문구, 핸드아웃, 실습 자료)에 출력 스타일 **fluent-korean**을 적용한다. 의미가 분명하고 조사·어미를 살린 한국어 문장을 쓰게 하는 지침이다. 다른 사람이 만든 것이라 이 묶음에는 넣지 않고 원본 주소만 적는다.

- 원본: https://github.com/snflkd/fluent-korean (`fluent-korean.md`)
- 설치: 그 파일을 `~/.claude/output-styles/fluent-korean.md`로 받은 뒤, Claude Code에서 `/output-style`로 fluent-korean을 고른다.
- 작업 폴더의 `CLAUDE.md`(이 묶음의 `지침/CLAUDE.md`)에 이 스타일을 강의 결과물에도 적용하는 조항이 있다.

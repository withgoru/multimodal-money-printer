#!/bin/bash
# 교안 파일 편집 시 정합성·재빌드·버전 관리 리마인드 (PostToolUse: Edit|Write)
# 공유본: 원 저장소(kyoans)의 훅에서 작성자 환경 경로만 일반화했다. 등록은 지침/settings.json.
# 실증 사고 3건(31p 롤백논리·day1/day1-done·핸드아웃 9곳 드리프트) 예방용.
# 2026-11-16: 대본을 덱의 강사 노트로 옮기고 md 쌍둥이를 없앤 개정(lecture-deck-author v2)에 맞춰 문구와 패턴을 바꿨다.
# 2026-11-18: 교안 체계 버전 관리(skills/), 블록 조립, 실습 자료와 화면 대조, 이전 버전 덱 폴더 보호를 더했다.
#   계기: 버전을 올리며 폴더 백업을 빠뜨림(성일 "백업들 안 해 뒀어? 버전별로 해 둬야지"), v2.5.0 "화면과 실습 자료 대조".
#   교안 체계 알림은 세션마다 한 번만 낸다(스킬을 고칠 때는 편집이 여러 번 이어지므로).
INPUT=$(cat)
IFS=$'\t' read -r FILE SID < <(printf '%s' "$INPUT" | python3 -c "import sys,json
d=json.load(sys.stdin); print((d.get('tool_input',{}).get('file_path','') or '-')+chr(9)+(d.get('session_id','') or 'nosession'))" 2>/dev/null)
[ -z "$FILE" ] || [ "$FILE" = "-" ] && exit 0

STATE_DIR="$HOME/.claude/state/lecture-sync"
once() {  # 세션마다 한 번만 알릴 때: once <이름> 이 0을 돌려주면 알린다
  mkdir -p "$STATE_DIR"
  local f="$STATE_DIR/${SID}.$1"
  [ -e "$f" ] && return 1
  touch "$f"; return 0
}

MSG=""
case "$FILE" in
  */skills/CHANGELOG.md|*/skills/VERSION|*/skills/README.md|*/skills/backup_version.sh) ;;
  */skills/lecture-*|*/교안설계원칙.md)
    once skills && MSG="[lecture-sync] 교안 체계 파일 수정됨 → skills/README.md 버전 올리기 순서: ① 고치기 전 버전의 태그(skills-v<VERSION>)와 백업 폴더 사본(v<VERSION>/)이 있는지 ② 끝나면 SKILL.md version과 변경 메모, VERSION, CHANGELOG ③ git add skills assets/교안설계원칙.md → 커밋 → 태그 → bash skills/backup_version.sh ④ .claude/skills/의 사본을 원본과 맞추고 세션을 다시 연다." ;;
  *_독립형.html) ;;
  */blocks/*.html|*/blocks/*.css|*/blocks/_계약.md)
    MSG="[lecture-sync] 덱 블록 수정됨 → ① 같은 값이 다른 블록에도 남았는지 찾기, 어긋남은 _계약.md에 되돌려 적기 ② python3 준비물/assemble_deck.py <덱 이름> 04_덱/<버전>로 조립 ③ build_standalone.py로 단일 파일 재생성." ;;
  *강의안*.html|*덱*.html)
    MSG="[lecture-sync] 덱 HTML 수정됨 → ① 핸드아웃 영향 점검(실행 환경·순서·프롬프트와 코드) ② 그 교안 전용 md를 두었다면 강사 노트와 정합 확인 ③ build_standalone.py로 단일 파일 재생성 필수." ;;
  */03_실습자료/README.md|*/03_실습자료/실측/*) ;;
  */03_실습자료/*.md|*/03_실습자료/*.ipynb)
    MSG="[lecture-sync] 실습 자료 수정됨 → ① 같은 활동의 덱 화면과 같은 지시인지 대조(활동 번호, 무엇을 어디에 쓰나, 어떤 도구, 새 대화, 누구 결과, 확인 줄) ② 수강생 자료에는 강사용 메모를 두지 않는다(강사용은 03_실습자료/README.md)." ;;
  *강의안*.md|*대본*.md)
    MSG="[lecture-sync] 교안 전용 md 수정됨 → ① 덱 강사 노트에도 같은 수정 반영 ② 핸드아웃 정합 점검 ③ 덱을 바꿨으면 단일 파일 재생성." ;;
  *핸드아웃*.md)
    MSG="[lecture-sync] 핸드아웃 수정됨 → ① 덱 시나리오와 정합 확인 ② build_handout_pdf.py로 PDF 재생성(중간 html은 커밋 금지)." ;;
esac

# 이전 버전 덱 폴더 보호: 04_덱/vX.Y.Z/ 안을 고쳤는데 같은 강의에 더 높은 버전 폴더가 있으면 알린다
if [[ "$FILE" =~ ^(.*/04_덱)/v([0-9]+\.[0-9]+\.[0-9]+)/ ]]; then
  DECK_DIR="${BASH_REMATCH[1]}"; VER="${BASH_REMATCH[2]}"
  NEWEST=$(ls -d "$DECK_DIR"/v*/ 2>/dev/null | sed -E 's#.*/v([0-9.]+)/$#\1#' | sort -V | tail -1)
  if [ -n "$NEWEST" ] && [ "$NEWEST" != "$VER" ]; then
    MSG="[lecture-sync] 이전 버전 덱 폴더(v${VER})를 고쳤습니다. 이전 버전 폴더는 고치지 않습니다(CLAUDE.md). 최신 폴더는 v${NEWEST}입니다. 실수라면 되돌리세요. ${MSG}"
  fi
fi

[ -z "$MSG" ] && exit 0
python3 -c "import json,sys; print(json.dumps({'hookSpecificOutput':{'hookEventName':'PostToolUse','additionalContext':sys.argv[1]}},ensure_ascii=False))" "$MSG"
exit 0

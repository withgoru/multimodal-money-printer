---
name: kdt
description: KDT 과정 하나를 표준 플로우(S0 자료 수집 → S11 회고·개정)에 따라 진행한다. 현재 단계와 막힌 이유를 Instructor Studio에서 읽고, 다음 단계 초안을 만들어 강사 승인을 받은 뒤 저장한다. "/kdt", "KDT 진행", "과정 다음 단계", "강의 플로우", "어디까지 됐어", "자료 재생성" 요청에 사용한다.
---

# /kdt — KDT 과정 표준 플로우

## 목차

- [원칙](#원칙)
- [시작 절차](#시작-절차)
- [단계별 진행표](#단계별-진행표)
- [자료 재생성](#자료-재생성)
- [보고 형식](#보고-형식)

## 원칙

- **상태의 기준은 Instructor Studio다.** 과정 데이터는 `output/course/studio/courses/{courseId}/course.json`에 있고, 단계 상태는 `get_flow_status`가 저장 데이터로 계산한다. 단계를 "완료"로 직접 표시하는 방법은 없다.
- **승인 전에는 저장하지 않는다.** 초안(목차·자료 연결·평가·운영표·데모 계획)은 강사에게 보여 주고, 승인받은 내용만 저장 도구로 보낸다.
- **확정(S9)과 검토 판단은 웹 화면에서 강사가 한다.** MCP에는 확정 도구가 없다. `http://127.0.0.1:4317`의 「검증·확정」을 안내한다.
- **근거 없는 사실을 만들지 않는다.** NCS 코드·수행준거는 `list_ncs_units`·`read_source`로 확인한 원문 위치만 쓴다. 휴강일은 강사가 확인한 날짜만 넣는다.
- 쓰기 도구에는 항상 `get_flow_status`·`get_course`에서 받은 최신 `revision`을 보낸다. 충돌 오류가 나면 다시 읽고 강사에게 알린다.

## 시작 절차

1. MCP 서버 `instructor-studio`가 연결되어 있는지 확인한다. 저장소 루트의 `.mcp.json`은 Claude용이며 Codex에는 별도 MCP 등록이 필요하다. 연결되지 않으면 클라이언트의 MCP 설정과 `apps/instructor-studio`의 의존성 설치 상태를 확인한다.
2. `list_courses` → 과정이 둘 이상이면 강사에게 고르게 한다(AskUserQuestion). 이후 모든 호출에 `courseId`를 넣는다.
3. `get_flow_status` → 현재 단계(`current`), 그 단계의 차단 사유 상위 5개, 진행률을 [보고 형식](#보고-형식)으로 보여 준다.
4. 강사가 "계속"을 원하면 현재 단계의 진행표를 따른다. 강사가 특정 단계를 지정하면 그 단계로 간다(앞 단계가 남아 있으면 그 사실을 함께 알린다).

## 오토파일럿 (S3~S8 한 번에)

S0~S2가 끝난 과정에서 S3 이후가 많이 남았으면 단계별 진행보다 오토파일럿을 먼저 제안한다.

1. 운영표 입력을 강사에게 묻는다: 개강일, 수업 요일(0=일~6=토), 하루 훈련시간, 강사가 확인한 휴강일. 공휴일을 추측해 넣지 않는다.
2. `start_autopilot`(courseId, revision, settings). 실제 과정은 반영 전까지 바뀌지 않는다고 알린다.
3. `get_autopilot`으로 진행을 확인한다. 몇 분 간격으로 보고하되 결과를 지어내지 않는다.
4. `awaiting_lessons`가 되면 `lessonPlan`의 교안 수·회차 수·예상 시간(추정치)을 보여 주고 강사에게 생성/건너뛰기를 묻는다(AskUserQuestion). 답을 받은 뒤에만 `decide_autopilot_lessons`를 호출한다.
5. `review`가 되면 단계별 생성 수, 확인 표시(`flagCounts`와 `flags` 상위 항목), 반영 시 예상 플로우(`flowAfter`)를 정리해 보여 준다. 확인 표시 종류: 범용 단원(placeholder), 자료 결정 확인(material_uncertain), 강사 입력 필요(needs_input: 데모 Git 기준점), 화면 명칭 미확인(ui_unverified), 운영표 위반, 생성 실패.
6. 강사가 반영을 승인하면 `apply_autopilot`(제외할 단계가 있으면 `exclude`). `conflicts`는 실행 중 강사가 직접 고친 부분이므로 그대로 보고한다. 폐기를 원하면 `discard_autopilot`.
7. `failed`면 `error`를 보여 주고, 원인(API 키·요청 한도)을 해결한 뒤 같은 `start_autopilot`으로 이어서 진행한다.

## 단계별 진행표

| 단계 | 할 일 | 읽기 | 저장 | 화면 |
|---|---|---|---|---|
| S0 자료 수집 | 레퍼런스가 필요하면 `AGENTS.md`의 「레퍼런스 수집해」 절차 | `list_sources` | — | 공용 자료실 |
| S1 과정 기획 | 대상·총시간·직무·최종 프로젝트·성취목표·필수 기술·제약 초안 | `get_course` | `save_brief` | 과정 기획서 |
| S2 교과 편성 | NCS 능력단위 근거로 교과·시간·평가 증거 제안. 프로젝트·비NCS 교과는 종류 지정 | `list_ncs_units`, `read_source` | `save_curriculum_draft`, `set_module_kind` | 교과 편성 |
| S3 교안 목차 | 교과마다 이론+실습 시간을 **모두** 채우는 단원 목록 제안 (실습 시간도 목차가 필요) | `read_source`, `list_sources` | `save_lesson_plan` | 교안 목차 |
| S4 자료 연결 | 항목마다 `suggest_materials`로 후보를 찾아 표로 보여 주고, 강사가 고른 자료는 reuse, 없으면 new | `suggest_materials` | `link_material` | 교안 목차 |
| S5 실습·데모 | 실습 차시마다 실습 설계, 강사 데모 3단계(build·automate·deploy)의 학생 과제·증거·Git 기준점·대체 실습 | `get_course` | `save_practice_draft`, `save_lesson_plan`(practiceId 연결), `save_demo_plan` | 실습 설계 |
| S6 교안 제작 | `new` 항목만 교안 생성. 웹 화면 또는 `npm run generate:lesson -- --course 과정ID --module 교과ID --item 항목ID`로 초안만 생성한다. CLI는 과정에 저장하지 않는다. 「시간 대비 분량」「코드·명령 예시」가 보완 확인이면 그 이유를 보고, 웹에서 PDF·원문을 검토한다 | `get_flow_status` | 웹 「PDF 검토 후 저장」 | 교안 생성 |
| S7 평가 설계 | 채택 능력단위마다 사전·사후 평가(문항·채점 해설·수행준거 근거), 프로젝트 교과 과제서·루브릭 | `list_ncs_units`, `read_source` | `save_assessment`, `save_project_brief` | 평가 설계 |
| S8 운영표 | 개강일·수업 요일·하루 시간·휴강일을 강사에게 묻고 `plan_schedule` 결과와 위반을 보여 준 뒤 승인 시 저장 | `plan_schedule` | `save_schedule` | 운영표 |
| S9 확정·배포 | `validate_course` 결과를 정리해 보여 주고 웹 확정을 안내 | `validate_course` | (웹에서 강사) | 검증·확정 |
| S10 수업 진행 | 날짜별 진행 상태·실제 시간·변경 사유, 데모 단계 진행·복구 기록 | `get_delivery` | `log_delivery` | 수업 진행 |
| S11 회고·개정 | 진행 기록과 회고를 요약하고 다음 기수 변경안 제시, 웹의 「새 초안」 분기 안내 | `get_delivery` | `log_delivery`(retrospective) | 검증·확정 |

평가 문항의 `scoringGuide`는 강사 전용이다. 수강생에게 보여 줄 문장에 채점 해설을 섞지 않는다.

## 자료 재생성

강사가 "자료 재생성"을 요청하면 종류를 묻고 아래 명령을 프로젝트 루트에서 순서대로 실행한다. 각 묶음의 마지막 검증 단계까지 실행하고 결과를 보고한다.

| 자료 | 명령 | 검증 |
|---|---|---|
| 1~10일차 통합덱 | `node apps/instructor-studio/tools/build-deck-masters.mjs --dry-run` → 확인 후 `--dry-run` 없이 실행 | 출력의 쪽수 검산 |
| 클라우드 학생용 원고·슬라이드 (`.env`의 `OPENAI_API_KEY` 필요) | `cd apps/instructor-studio && node tools/build-cloud-authored-content.mjs` → `node tools/render-cloud-authored-slides.mjs` | `node tools/audit-cloud-authored-content.mjs`, `node tools/check-cloud-slides.mjs` 후 `node tools/export-cloud-slide-pdfs.mjs` |
| 클라우드 통합 PDF·ZIP·다운로드 목차 | `node output/course/cloud-engineering-materials/build-merged-pdfs.mjs` → `build-module-zip.mjs` → `build-download-index.mjs` | 생성 ZIP 목록 확인. ZIP·통합 PDF는 Git에서 제외된 재생성 산출물 |
| 클라우드 문서 미리보기·문서 ZIP | `node output/course/build-markdown-previews.mjs` → `node output/course/cloud-engineering-materials/build-document-zips.mjs` → `build-download-index.mjs` | ZIP 무결성은 스크립트가 `unzip -t`로 확인 |
| 게시판 연계 수업 HTML 슬라이드 | `node output/course/vibe-coding-board/build-concept-slides.mjs`, `node output/course/infra-basics-board/build-slides.mjs`, `node output/course/board-docker-aws-deploy/build-slides.mjs` | 생성된 `slides.html`을 브라우저로 확인. 이 스크립트들은 PDF를 만들지 않으므로 `slides.pdf`·통합덱 PDF는 별도로 갱신해야 한다 |
| 자료실 색인 | 웹 공용 자료실의 「다시 읽기」 또는 MCP `list_sources` | 추출 실패 0건 |

슬라이드를 새로 만드는 요청은 `AGENTS.md`의 「슬라이드 디자인 기본값」을 따른다.

## 보고 형식

```
과정: {name} ({courseId}) · 상태 {status} · revision {n}
현재 단계: {id} {title} — {done}/{total}
막힌 이유:
  1. {message} → {화면}
  ...
다음 제안: {이번에 만들 초안 한 줄}
```

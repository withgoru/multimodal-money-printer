# 원래 KDT 작업 공간의 의존 자료

이 저장소는 `kdt/marketing-growth/`의 공개용 복사본이다. 원래 작업 공간의 Instructor Studio, Claude `/kdt` 스킬, 전체 33건의 공용 레퍼런스, 다른 분야의 교안, 기존 제작 절차 발표덱, 전체 NCS 원본 선택표는 포함하지 않는다. 문서의 Studio 과정 ID·revision·S0~S11 상태는 **2026-11-18 당시의 작업 기록**이며, 이 저장소만으로 현재 Studio 상태를 조회하거나 과정을 확정할 수 없다.

이 저장소에서 다시 사용할 수 있는 제작 도구는 [공용 교안 제작 스킬](../tooling/lesson-author/SKILL.md)과 [HTML 슬라이드 템플릿](../tooling/slides-template/README.md)이다. 원래 프로젝트의 [작업 원칙](../tooling/constitution.md)도 함께 보존했다. KDT 전용 어댑터와 원래 경로를 언급하는 예시는 당시 환경의 기록이므로 독립 실행 전에 경로를 조정한다.

원래 작업 공간에서 참조하던 다른 분야의 자료는 이 과정의 원문 근거가 아니다. 과정의 직접 근거는 [참고 자료 목록](INDEX.md), [근거 목록](../evidence/근거_목록.md), [과정 기획서](../과정_기획서.md)에서 확인한다.

## 공개본 동기화 확인 · 2026-11-18

원래 `kdt/marketing-growth/`와 공개본의 파일을 다시 대조했다. 최초 게시 이후 추가된 과정 파일이나 새로운 본문 수정은 없었다. 공개본의 문서 차이는 독립 저장소에서 작동하도록 바꾼 상대 경로와 원문 출처 링크다.

최초 공개 당시 원래 작업 폴더에서 `M1-1-P` 초안 5개 파일은 삭제 상태였다. 여러 과정 문서가 이 차시를 참조하므로 공개본에는 원래 KDT 커밋 `116eff3`의 파일을 유지했다. 외부 논문과 NCS 원본 PDF는 공개본에 복사하지 않고 원문 위치와 공식 검색 경로를 안내한다.

이후 KDT 저장소의 `3e61e7b`에서 과정 폴더 전체를 Git 추적에 포함하고 `M1-1-P` 파일을 복원했다. 이 공개본에는 그 뒤 추가된 [통합 과정 기획서 PDF](https://github.com/withgoru/multimodal-money-printer/blob/7cf609189edffb59d1c85027b948c1be5659d5a7/slide_resource/%EB%B0%95%EC%88%98%EC%A0%95/marketing-growth/%EC%B5%9C%EC%A2%85_%EA%B3%BC%EC%A0%95_%EA%B8%B0%ED%9A%8D%EC%84%9C.pdf)와 [팀 기획서 비교 자료](https://github.com/withgoru/multimodal-money-printer/blob/7cf609189edffb59d1c85027b948c1be5659d5a7/slide_resource/%EB%B0%95%EC%88%98%EC%A0%95/marketing-growth/team-agents/%EA%B8%B0%ED%9A%8D%EC%84%9C/%EA%B8%B0%ED%9A%8D%EC%84%9C_%EB%B9%84%EA%B5%90.md)를 반영했다. 외부 원문 PDF 제외 원칙은 유지한다.

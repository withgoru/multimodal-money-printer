# 산출물 2 · 박수정의 그로스 마케팅 교안 제작 에이전트

112시간 그로스 마케팅 과정에서 사용한 교안 스킬, 입출력 계약과 검증기, 작업 지침을 묶었다. 2026년 11월 18일 제작 세션에서 확인한 사용 순서와 결과는 [세션 기록](SESSION-NOTES.md)에 있다.

| 구성 | 시작 파일 |
|---|---|
| 교안 스킬과 검증 도구 | [lesson-author/SKILL.md](marketing-growth/tooling/lesson-author/SKILL.md), [5개 제작 모듈](marketing-growth/tooling/lesson-author/references/modules.md), [산출물 계약](marketing-growth/tooling/lesson-author/references/artifact-contract.md), [Node.js 검증기](marketing-growth/tooling/lesson-author/scripts/validate.mjs) |
| 과정별 지침과 하네스 | [과정 AGENTS.md](marketing-growth/AGENTS.md), [프로젝트 작업 원칙](marketing-growth/tooling/constitution.md), [KDT 과정 플로우](marketing-growth/tooling/kdt/SKILL.md), [Studio MCP 설정 예시](marketing-growth/tooling/kdt/mcp.example.json), [제작 시스템 매뉴얼](marketing-growth/pdf/kdt-team-system-and-agents.pdf) |
| 교안 입력과 실물 예시 | [교과·차시 편성](marketing-growth/교과_차시_편성.md), [NCS 원문 확인 경로](marketing-growth/references/NCS.md), [R1 가상 캠페인 CSV](marketing-growth/evidence/multimodal-assets/daily_campaign_metrics.csv), [M1-1-T HTML](marketing-growth/lesson-drafts/M1-1-T/lesson.html), [M1-1-T PDF](marketing-growth/lesson-drafts/M1-1-T/lesson.pdf), [M1-1-P 학생 활동지](marketing-growth/lesson-drafts/M1-1-P/practice.md) |
| 발표 및 팀 인계 | [HTML 슬라이드 템플릿](marketing-growth/tooling/slides-template/README.md), [팀 역할별 요청문과 인계 규칙](marketing-growth/team-agents/README.md) |

## 교안 제작 다시 실행하기

압축을 푼 폴더를 Claude Code 또는 Codex에서 열고, 아래 예시처럼 에이전트에게 파일을 지정한다. 기존 교안 예시를 보존하려면 요청문의 출력 폴더를 새 경로로 지정한다.

> `marketing-growth/AGENTS.md`와 `marketing-growth/tooling/lesson-author/SKILL.md`를 읽어. 편성표에서 M1-1-T 이론 180분을 확인하고, 워크북과 R1 합성 CSV, NCS 원문 확인 경로를 사용해 이론 차시 초안을 만들어 줘. 광고 목표·전환 퍼널·KPI 정의를 다루고, 강사용 진행안과 학생 활동지를 분리해. 확인할 수 있는 원문 위치를 기록하고 확인이 필요한 내용은 검토 기록에 남겨. 초안 파일 5개와 HTML·PDF는 `drafts/M1-1-T/`에 저장해.

압축을 푼 최상위 폴더에서 Node.js로 예제의 시간 합계, 출처 ID 연결, 필수 파일을 확인한다.

```sh
node marketing-growth/tooling/lesson-author/scripts/validate.mjs marketing-growth/lesson-drafts/M1-1-P
node marketing-growth/tooling/lesson-author/scripts/validate.mjs marketing-growth/lesson-drafts/M1-1-T --with-slides
```

예제 검사에는 Node.js 외에 설치할 패키지나 API 키가 없다. 생성한 HTML은 브라우저에서 열고 PDF는 페이지 순서·글자 잘림을 확인한다. 실제 수업 시간, 원문이 설명을 뒷받침하는지, 학생이 실습을 수행할 수 있는지는 강사가 검토한다.

KDT 플로우와 MCP 설정을 실행하려면 Instructor Studio가 설치된 원래 KDT 작업 공간이 필요하다. 패키지에서는 교안 작성과 구조 검사를 독립적으로 실행할 수 있다. 전체 학습 PDF, 다른 차시의 데이터·소재, 데모는 팀 저장소의 과정 자료에서 확인할 수 있다. [팀 저장소의 과정 자료](https://github.com/withgoru/multimodal-money-printer/tree/7cf609189edffb59d1c85027b948c1be5659d5a7/slide_resource/박수정/marketing-growth)

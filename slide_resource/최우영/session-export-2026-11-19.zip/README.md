# 세션 내보내기 (2026-11-19)
- transcript/  이 세션의 전체 대화 기록(JSONL, 한 줄이 한 이벤트)
- harness/project/  AGENTS.md, .claude/launch.json, 교안 스타일·컴포넌트, 팀 발표 교안, package.json
- harness/user-claude/settings.json  사용자 설정(model 항목만 있음)
- skills/  계정에 동기화된 스킬 목록(Anthropic 제공 스킬, 직접 만든 스킬 아님)
제외: API 키·로그인 정보·원격 설정 서명 파일, 다른 세션 기록, 휴지통 스킬
